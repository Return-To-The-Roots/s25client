#!/bin/sh
#
# $Id: make-src.sh,v 1.1 2007-08-23 14:30:24 patrickm Exp $
#
#       Not implemented yet on OS/400.
